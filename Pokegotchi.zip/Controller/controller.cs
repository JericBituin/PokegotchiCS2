namespace Controller;

public class PokedexController{
    
}